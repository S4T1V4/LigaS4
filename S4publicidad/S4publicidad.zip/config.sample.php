<?php
declare(strict_types=1);

/**
 * CONFIG S4publicidad (muestra)
 * - Copia a: /S4publicidad/config.php
 * - Tip: genera un hash con:
 *   php -r "echo password_hash('TU_PASS_AQUI', PASSWORD_DEFAULT);"
 *  Para ejecutarlo en Docker [*] docker exec -it web php -r "echo password_hash('##GUTY_2026', PASSWORD_DEFAULT);"
 *
 * Nota:
 * - Si NO configuras aquí supabase_url/service_role, se intentará tomar del config raíz.
 * - Si NO configuras aquí admin_password_hash, se intentará reutilizar el del admin principal.
 */
return [
    // Puedes poner un hash distinto SOLO para S4publicidad (opcional)
    'admin_password_hash' => '$2y$10$n7vGB/MFLWnJ648H6dOmQO7MKSpyyafXWok6GskrINknRnFfh.iJy',

    // Nombre de sesión independiente del /admin principal
    'session_name' => 's4publicidad_admin',

    // =====================================================
    // Supabase (SERVER-SIDE)
    // =====================================================
    'supabase_url' => 'https://exookdvbzclebrekliub.supabase.co',
    'supabase_service_role_key' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV4b29rZHZiemNsZWJyZWtsaXViIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODUwNDg2MywiZXhwIjoyMDg0MDgwODYzfQ.n3rVV8BxajN-CWHldwmGJmxe3yrDpEBssho8KL1q0YM',

    // Bucket de Storage donde se guardan imágenes de publicidad
    'supabase_publicidad_bucket' => 'media',

    // Tabla Postgres (schema public)
    'supabase_publicidad_table' => 'publicidad',
];
