<?php
declare(strict_types=1);

/**
 * CONFIG
 * - En producción deja SOLO config.php.
 * - Tip: genera un hash con:
 *   php -r "echo password_hash('TU_PASS', PASSWORD_DEFAULT);"
 */
return [
    'admin_password_hash' => '$2y$10$n7vGB/MFLWnJ648H6dOmQO7MKSpyyafXWok6GskrINknRnFfh.iJy',
    'session_name' => 'liga_guty_admin',
    'admin_base_path' => '/S4publicidad',

    // Supabase (SERVER-SIDE)
    'supabase_url' => 'https://exookdvbzclebrekliub.supabase.co',
    'supabase_service_role_key' => 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV4b29rZHZiemNsZWJyZWtsaXViIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODUwNDg2MywiZXhwIjoyMDg0MDgwODYzfQ.n3rVV8BxajN-CWHldwmGJmxe3yrDpEBssho8KL1q0YM',
    'supabase_publicidad_bucket' => 'media',

    'supabase_publicidad_table' => 'publicidad',
];
