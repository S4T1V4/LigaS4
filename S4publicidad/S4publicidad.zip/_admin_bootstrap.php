<?php
declare(strict_types=1);

require_once __DIR__ . '/_bootstrap.php';

lf_require_admin();

$MODE = 'admin_publicidad';
$is_admin = true;
